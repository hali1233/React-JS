import React, {useState} from 'react'

export default function TextForm(props) {
    const handleUpClick = ()=>{
        let newText = text.toUpperCase();
        setText(newText)
    }
    const handleLoClick = ()=>{
        let newText = text.toLocaleLowerCase();
        setText(newText)
    }
    const handleClearClick = ()=>{
        let newText = '';
        setText(newText)
    }
    const handleReverseClick = () =>{
        let newText = text.split("");
        let reverseText = newText.reverse();
        let joinText = reverseText.join("");
        setText(joinText);
    }
    const handleOnChange = (event)=>{
        // console.log("on change");
        setText(event.target.value)
    }

    const[text, setText] = useState('');
    return (
    <>
    <div className='container'>
      <h2>{props.heading}</h2>
      <div className="mb-3">
        <textarea className="form-control" value = {text} onChange={handleOnChange} id="myBox" rows="8" ></textarea>
      </div>
      <button className="btn btn-outline-danger" onClick={handleUpClick}>Convert to uppperCase</button>
      <button className="btn btn-outline-danger mx-2" onClick={handleLoClick}>Convert to lowerCase</button>
      <button className="btn btn-outline-danger mx-2" onClick={handleClearClick}>Clear text</button>
      <button className="btn btn-outline-danger mx-2" onClick={handleReverseClick}>Reverse text</button>
    </div>
    <div className="container my-3">
        <h2>Text Summary is</h2>
        <p>{text.split(" ").length} word and {text.length} characters</p>
        <p>{0.008 * text.split(" ").length} Minutes read</p>
        <h2>Preview</h2>
        <p>{text}</p>
    </div>
    </>
  );
}

